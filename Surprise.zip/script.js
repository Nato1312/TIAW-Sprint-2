// declaração de variável

var a = 0 // variável geral
{
let = 1// variável local
  let1= "java script"
}


/** Botão deletar */

document.queySelector('.delete-btn').addEventListener('click', function(){
document.querySelector('.container').classList.add('active'),
document.getElementById("delete").style.zIndex = "-1";

});


function closeCont(){

document.querySelector('.container').classList.remove('active'),
document.getElementById("delete").style.zIndex = "1";

}


/** Botão deletar */




